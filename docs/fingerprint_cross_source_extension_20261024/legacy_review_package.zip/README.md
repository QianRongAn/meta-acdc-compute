# Legacy v2 diagnostic matrix package

331 graph positions; 160 observed-chain string labels; 55 labels have at least two graphs. Use graph_index for BOTH similarity axes and embedding rows. Keep the exact original fold assignment. Do not reconstruct identity from PDB names.

The original records do not store MHC; null means unverified, not absence of MHC. Legacy labels are not complete paired-variable identity. canonical_paired_variable_id is populated only for previously admitted evidence, otherwise unknown.

All 15 original per-instance pooled pair AUROC metrics are replayed exactly, including 0.7943805448628184 mean-fold AUROC for seed20261021. This is retrospective order/metric binding; old metrics lack contemporaneous per-instance dataset hashes. No biological performance claim is restored.

No graphs or new models are included. No independent acceptance data were accessed. See EXTERNAL_REVIEW_RESPONSE.md in the source repository for interpretation and later corrected runs.
